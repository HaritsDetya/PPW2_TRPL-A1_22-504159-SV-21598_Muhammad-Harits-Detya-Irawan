@extends('barang')

@section('judul halaman', 'Quiz PPW 2')

@section('isi')
    <p>Welcome !!!</p>
@endsection