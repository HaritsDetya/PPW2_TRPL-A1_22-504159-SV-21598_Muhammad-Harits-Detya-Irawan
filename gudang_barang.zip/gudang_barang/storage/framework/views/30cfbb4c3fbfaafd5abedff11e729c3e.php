<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <title>Gudang Barang</title>
</head>
<body>
    <br>
    <h1><?php echo $__env->yieldContent('judul halaman'); ?></h1>

    <?php echo $__env->yieldContent('isi'); ?>
    <br>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>id</th>
                <th>Nama Barang</th>
                <th>Harga</th>
                <th>Stok</th>
                <th>id Suplier</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $data_barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $barang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e(++$no); ?></td>
                    <td><?php echo e($barang->nama_barang); ?></td>
                    <td><?php echo e($barang->harga); ?></td>
                    <td><?php echo e($barang->stok); ?></td>
                    <td><?php echo e($barang->id_suplier); ?></td>
                </tr>
                <td>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <p>Jumlah Data: <?php echo e($totalData); ?></p>
</body>
</html><?php /**PATH C:\Users\ASUS\gudang_barang\resources\views/gudang/barang.blade.php ENDPATH**/ ?>